library(Seurat)
library(dplyr)
library(Matrix)
library(gdata)
library(reshape2)
library(data.table)
library(ggplot2)
library(cowplot)
library(harmony)
library(gridExtra)
library(vegan)
library(tcR)
library(gtools)
library(ggpubr)
library(treemapify)
library(diverse)
library(tabula)
library(magrittr)
library(stringr)
downsample_DT<-function(dflist_list,n=10000,colname="cloneCount"){
  dflist=dflist_list
  dflist_copy<-lapply(dflist,copy)
  dflist_copy<-lapply(dflist_copy,function(x){x[,Read.count.down:=rmultinom(1,n,get(colname)/sum(get(colname))),];x})
  dflist_copy<-lapply(dflist_copy,function(x){x[Read.count.down>0,colname:=Read.count.down,];x})
  dflist_copy<-lapply(dflist_copy,function(x){x[Read.count.down>0,,]})
  return(dflist_copy)
}
##########################################################################################

#############################################################################################
date1="200810"
meta=fread("metadata/Sequenced_sample_metadata_020720.csv")
sc_meta=meta[meta$scRNAseqID!="",]
meta$Name=gsub("PC_","",meta$Name)
meta$Name=gsub("Ki","Ki_",meta$Name)
meta$Name=gsub("Co","Co_",meta$Name)
##########################################################################################
load("single_cell/data/COVIDomics_clonotypes_BCR_filtered2.Rdata")
unlist(lapply(BCRclono,function(x) nrow(x)))
unlist(lapply(BCRclono,function(x) sum(x$frequency)))

BCRclono2=BCRclono[which(unlist(lapply(BCRclono,function(x) nrow(x)))>100)]
down=downsample_DT(dflist_list=lapply(BCRclono2, function(x) as.data.table(x)),n=min(unlist(lapply(BCRclono2,function(x) sum(x$frequency)))),colname="frequency")
down=lapply(down,function(x){
  y=x
  y$newFraction=y$Read.count.down/sum(y$Read.count.down)
  y
})
down=lapply(down, function(x) x[order(x$Read.count.down,decreasing=T),])
names(down)=names(BCRclono2)
save(down,file= "COVIDomics_BCR_sc_downsampled_1.Rdata")

norm_clonotypes=cbind(unlist(lapply(down,function(x) length(x$Read.count.down))))
gini_index=cbind(unlist(lapply(down,function(x) tcR::gini(x$Read.count.down))))
inv_simp=cbind(unlist(lapply(down,function(x) vegan::diversity(x$Read.count.down,index="invsimpson"))))
clonality=cbind(unlist(lapply(down,function(x) 1/(vegan::diversity(x$Read.count.down,index="shannon")))))

divers<-data.frame(Name=row.names(norm_clonotypes),No.clones=norm_clonotypes,
                   Inv.Simpson=inv_simp,Gini=gini_index, Clonality=clonality)
diversity_table=merge(divers,meta,by=c("Name"),all.x=T)
write.table(diversity_table,"COVIDomics_BCR_sc_diversity_1.txt",
            row.names=FALSE , quote=FALSE, sep="\t",dec=".")


mod_melt=merge(melt(divers),meta,by=c("Name"),all.x=T)
mod_melt$Pseudotime=factor(mod_melt$Pseudotime, levels=c(0:7))
mod_melt=mod_melt[order(mod_melt$Pseudotime),]
mod_melt$Disease_traj=factor(mod_melt$Disease_traj, levels=unique(mod_melt$Disease_traj))

mod_melt$Diagnosis=rep("COVID-19",nrow(mod_melt))
mod_melt$Diagnosis=ifelse(grepl("Healthy",mod_melt$Disease_traj),gsub("COVID-19","Healthy",mod_melt$Diagnosis),mod_melt$Diagnosis)

div=ggplot(data=mod_melt,aes(y=value,x=TimepointFromOnset, group=PatientID)) +
  geom_line(color="Grey") +
  geom_point(size=2.5, aes(color=Pseudotime)) + 
  scale_color_manual(values=c("0"="#A7A9AC","1"="#E84F8C","2"="#7031B9","3"="#A04E9E","4"="#E65826","5"="#F99B1C",
                              "6"="#FDC077","7"="#51BBFE"),
                              labels=c("0"="Healthy","1"="Complicated (incremental)",
                                       "2"="Critical","3"="Complicated with hyperinflammatory syndrom",
                                       "4"="Complicated (recovering)","5"="Mild (recovering)",
                                       "6"="recovery/asymptomatic","7"="Recovered")) +
  guides(color=F) +
  facet_grid(variable~.,scale="free") + 
  theme_bw() +
  #  stat_summary(fun.y= median, fun.ymin = median, fun.ymax = median,
  #               geom = "crossbar", width = 0.4) +
  labs(y = "Diversity measure",
       x="Time",
       title="") +
  theme(text = element_text(size=12),
        axis.text.x =element_text(size=12),
        axis.title.x =element_text(size=12),
        strip.text = element_text(size = 12),
        axis.text.y =element_text(size=12),
        axis.title.y=element_text(size=12)) 
#figure2A1<-ggMarginal(figure2A1,type="boxplot", groupColour=TRUE, margins="y")

div2=ggplot(data=mod_melt,aes(y=value,x=Pseudotime)) +
  geom_point(size=3, aes(color=Pseudotime)) + 
  scale_color_manual(values=c("0"="#A7A9AC","1"="#E84F8C","2"="#7031B9","3"="#A04E9E","4"="#E65826","5"="#F99B1C",
                              "6"="#FDC077","7"="#51BBFE"),
                     labels=c("0"="Healthy","1"="Complicated (incremental)",
                              "2"="Critical","3"="Complicated with hyperinflammatory syndrom",
                              "4"="Complicated (recovering)","5"="Mild (recovering)",
                              "6"="recovery/asymptomatic","7"="Recovered")) +
  guides(color=guide_legend("Disease\ntrajectory")) +
  facet_grid(variable~.,scale="free",space="free_x") + 
  theme_bw() +
  stat_summary(fun.y= median, fun.ymin = median, fun.ymax = median,
               geom = "crossbar", width = 0.4) +
  labs(y = "Diversity measure",
       x="Disease severity",
       title="") +
  theme(text = element_text(size=12),
        axis.text.x =element_text(size=12),
        axis.title.x =element_text(size=12),
        strip.text = element_text(size = 12),
        axis.text.y =element_text(size=12),
        axis.title.y=element_text(size=12)) 

ggsave(plot=grid.arrange(grobs=list(div,div2),ncol=2),
       "diversity_measures_v1.pdf", width=12,height=10, useDingbats=FALSE, dpi=300)
#################################################################################################################
classes=lapply(1:length(BCRclono2), function(x) {
  y=BCRclono2[[x]]
  y$class=rep("None",nrow(y))
  y$class=ifelse(grepl("IGHA",y$c_gene),gsub("None","IGHA",y$class),y$class)
  y$class=ifelse(grepl("IGHM",y$c_gene),gsub("None","IGHM",y$class),y$class)
  y$class=ifelse(grepl("IGHG",y$c_gene),gsub("None","IGHG",y$class),y$class)
  y$class=ifelse(grepl("IGHE",y$c_gene),gsub("None","IGHE",y$class),y$class)
  y$class=ifelse(grepl("IGHD",y$c_gene),gsub("None","IGHD",y$class),y$class)
  y=y[y$class!="None",]
  y
})

classes=do.call(rbind,lapply(1:length(classes), function(x) {
  y=classes[[x]]
  y=y[1:min(unlist(lapply(classes,function(x) nrow(x)))),]
    z=data.frame(class_clonotype=cbind(table(y$class)))
    z$class=row.names(z)
    z$Name=rep(names(BCRclono2)[x],nrow(z))
    z$class_clonotype=z$class_clonotype/min(unlist(lapply(classes,function(x) nrow(x))))
    z
    }))

mod_melt=merge(classes,meta,by=c("Name"),all.x=T)

mod_melt$Pseudotime=factor(mod_melt$Pseudotime, levels=c(0:7))
mod_melt=mod_melt[order(mod_melt$Pseudotime),]
mod_melt$Disease_traj=factor(mod_melt$Disease_traj, levels=unique(mod_melt$Disease_traj))

mod_melt$Diagnosis=rep("COVID-19",nrow(mod_melt))
mod_melt$Diagnosis=ifelse(grepl("Healthy",mod_melt$Disease_traj),gsub("COVID-19","Healthy",mod_melt$Diagnosis),mod_melt$Diagnosis)
#mod_melt=mod_melt[order(mod_melt$Diagnosis),]
#mod_melt$PatientID=factor(mod_melt$PatientID, levels=unique(mod_melt$PatientID))
#mod_melt$color_code=factor(mod_melt$color_code, levels=unique(mod_melt$color_code))


div=ggplot(data=mod_melt,aes(y=class_clonotype,x=TimepointFromOnset, group=PatientID)) +
  geom_line(color="Grey") +
  geom_point(size=2.5, aes(color=Pseudotime)) + 
  scale_color_manual(values=c("0"="#A7A9AC","1"="#E84F8C","2"="#7031B9","3"="#A04E9E","4"="#E65826","5"="#F99B1C",
                              "6"="#FDC077","7"="#51BBFE"),
                     labels=c("0"="Healthy","1"="Complicated (incremental)",
                              "2"="Critical","3"="Complicated with hyperinflammatory syndrom",
                              "4"="Complicated (recovering)","5"="Mild (recovering)",
                              "6"="recovery/asymptomatic","7"="Recovered")) +
  guides(color=F) +
  facet_grid(class~.,scale="free") + 
  theme_bw() +
  #  stat_summary(fun.y= median, fun.ymin = median, fun.ymax = median,
  #               geom = "crossbar", width = 0.4) +
  labs(y = "Diversity measure",
       x="Time",
       title="") +
  theme(text = element_text(size=12),
        axis.text.x =element_text(size=12),
        axis.title.x =element_text(size=12),
        strip.text = element_text(size = 12),
        axis.text.y =element_text(size=12),
        axis.title.y=element_text(size=12)) 

div2=ggplot(data=mod_melt,aes(y=class_clonotype,x=Pseudotime)) +
  geom_point(size=3, aes(color=Pseudotime)) + 
  scale_color_manual(values=c("0"="#A7A9AC","1"="#E84F8C","2"="#7031B9","3"="#A04E9E","4"="#E65826","5"="#F99B1C",
                              "6"="#FDC077","7"="#51BBFE"),
                     labels=c("0"="Healthy","1"="Complicated (incremental)",
                              "2"="Critical","3"="Complicated with hyperinflammatory syndrom",
                              "4"="Complicated (recovering)","5"="Mild (recovering)",
                              "6"="recovery/asymptomatic","7"="Recovered")) +
  guides(color=guide_legend("Disease\ntrajectory")) +
  facet_grid(class~.,scale="free",space="free_x") + 
  theme_bw() +
  stat_summary(fun.y= median, fun.ymin = median, fun.ymax = median,
               geom = "crossbar", width = 0.4) +
  labs(y = "BCR proportion per class",
       x="Pseudotime",
       title="") +
  theme(text = element_text(size=12),
        axis.text.x =element_text(size=12),
        axis.title.x =element_text(size=12),
        strip.text = element_text(size = 12),
        axis.text.y =element_text(size=12),
        axis.title.y=element_text(size=12)) 

ggsave(plot=grid.arrange(grobs=list(div,div2),ncol=2),
       "diversity_measures_classes_sc_v1.pdf", width=12,height=10, useDingbats=FALSE, dpi=300)
################################################################################################################
BCRclono2=BCRclono[which(unlist(lapply(BCRclono,function(x) nrow(x)))>50)]
down=lapply(BCRclono2,function(x) x[1:50,])
down=lapply(down,function(x){
  y=x
  y$newFraction=y$frequency/sum(y$frequency)
  y
})
names(down)=names(BCRclono2)
save(down,file= "COVIDomics_BCR_sc_top50.Rdata")

norm_clonotypes=cbind(unlist(lapply(down,function(x) length(x$Read.count.down))))
gini_index=cbind(unlist(lapply(down,function(x) tcR::gini(x$Read.count.down))))
inv_simp=cbind(unlist(lapply(down,function(x) vegan::diversity(x$Read.count.down,index="invsimpson"))))
clonality=cbind(unlist(lapply(down,function(x) 1/(vegan::diversity(x$Read.count.down,index="shannon")))))

divers<-data.frame(Name=row.names(norm_clonotypes),No.clones=norm_clonotypes,
                   Inv.Simpson=inv_simp,Gini=gini_index, Clonality=clonality)
diversity_table=merge(divers,meta,by=c("Name"),all.x=T)
write.table(diversity_table,"COVIDomics_BCR_sc_diversity_top50.txt",
            row.names=FALSE , quote=FALSE, sep="\t",dec=".")


mod_melt=merge(melt(divers),meta,by=c("Name"),all.x=T)
mod_melt$Pseudotime=factor(mod_melt$Pseudotime, levels=c(0:7))
mod_melt=mod_melt[order(mod_melt$Pseudotime),]
mod_melt$Disease_traj=factor(mod_melt$Disease_traj, levels=unique(mod_melt$Disease_traj))

mod_melt$Diagnosis=rep("COVID-19",nrow(mod_melt))
mod_melt$Diagnosis=ifelse(grepl("Healthy",mod_melt$Disease_traj),gsub("COVID-19","Healthy",mod_melt$Diagnosis),mod_melt$Diagnosis)


div2=ggplot(data=mod_melt,aes(y=value,x=Pseudotime)) +
  geom_point(size=3, aes(color=Pseudotime)) + 
  scale_color_manual(values=c("0"="#A7A9AC","1"="#E84F8C","2"="#7031B9","3"="#A04E9E","4"="#E65826","5"="#F99B1C",
                              "6"="#FDC077","7"="#51BBFE"),
                     labels=c("0"="Healthy","1"="Complicated (incremental)",
                              "2"="Critical","3"="Complicated with hyperinflammatory syndrom",
                              "4"="Complicated (recovering)","5"="Mild (recovering)",
                              "6"="recovery/asymptomatic","7"="Recovered")) +
  guides(color=guide_legend("Disease\ntrajectory")) +
  facet_grid(variable~.,scale="free",space="free_x") + 
  theme_bw() +
  stat_summary(fun.y= median, fun.ymin = median, fun.ymax = median,
               geom = "crossbar", width = 0.4) +
  labs(y = "Diversity measure",
       x="Disease severity",
       title="") +
  theme(text = element_text(size=12),
        axis.text.x =element_text(size=12),
        axis.title.x =element_text(size=12),
        strip.text = element_text(size = 12),
        axis.text.y =element_text(size=12),
        axis.title.y=element_text(size=12)) 

#################################################################################################################
classes=lapply(1:length(BCRclono2), function(x) {
  y=BCRclono2[[x]]
  y$class=rep("None",nrow(y))
  y$class=ifelse(grepl("IGHA",y$c_gene),gsub("None","IGHA",y$class),y$class)
  y$class=ifelse(grepl("IGHM",y$c_gene),gsub("None","IGHM",y$class),y$class)
  y$class=ifelse(grepl("IGHG",y$c_gene),gsub("None","IGHG",y$class),y$class)
  y$class=ifelse(grepl("IGHE",y$c_gene),gsub("None","IGHE",y$class),y$class)
  y$class=ifelse(grepl("IGHD",y$c_gene),gsub("None","IGHD",y$class),y$class)
  y=y[y$class!="None",]
  y
})

classes=do.call(rbind,lapply(1:length(classes), function(x) {
  y=classes[[x]]
  y=y[1:min(unlist(lapply(classes,function(x) nrow(x)))),]
  z=data.frame(class_clonotype=cbind(table(y$class)))
  z$class=row.names(z)
  z$Name=rep(names(BCRclono2)[x],nrow(z))
  z$class_clonotype=z$class_clonotype/min(unlist(lapply(classes,function(x) nrow(x))))
  z
}))

mod_melt=merge(classes,meta,by=c("Name"),all.x=T)

mod_melt$Pseudotime=factor(mod_melt$Pseudotime, levels=c(0:7))
mod_melt=mod_melt[order(mod_melt$Pseudotime),]
mod_melt$Disease_traj=factor(mod_melt$Disease_traj, levels=unique(mod_melt$Disease_traj))

mod_melt$Diagnosis=rep("COVID-19",nrow(mod_melt))
mod_melt$Diagnosis=ifelse(grepl("Healthy",mod_melt$Disease_traj),gsub("COVID-19","Healthy",mod_melt$Diagnosis),mod_melt$Diagnosis)
#mod_melt=mod_melt[order(mod_melt$Diagnosis),]
#mod_melt$PatientID=factor(mod_melt$PatientID, levels=unique(mod_melt$PatientID))
#mod_melt$color_code=factor(mod_melt$color_code, levels=unique(mod_melt$color_code))


div3=ggplot(data=mod_melt,aes(y=class_clonotype,x=Pseudotime)) +
  geom_point(size=3, aes(color=Pseudotime)) + 
  scale_color_manual(values=c("0"="#A7A9AC","1"="#E84F8C","2"="#7031B9","3"="#A04E9E","4"="#E65826","5"="#F99B1C",
                              "6"="#FDC077","7"="#51BBFE"),
                     labels=c("0"="Healthy","1"="Complicated (incremental)",
                              "2"="Critical","3"="Complicated with hyperinflammatory syndrom",
                              "4"="Complicated (recovering)","5"="Mild (recovering)",
                              "6"="recovery/asymptomatic","7"="Recovered")) +
  guides(color=guide_legend("Disease\ntrajectory")) +
  facet_grid(class~.,scale="free",space="free_x") + 
  theme_bw() +
  stat_summary(fun.y= median, fun.ymin = median, fun.ymax = median,
               geom = "crossbar", width = 0.4) +
  labs(y = "BCR proportion per class",
       x="Pseudotime",
       title="") +
  theme(text = element_text(size=12),
        axis.text.x =element_text(size=12),
        axis.title.x =element_text(size=12),
        strip.text = element_text(size = 12),
        axis.text.y =element_text(size=12),
        axis.title.y=element_text(size=12)) 

ggsave(plot=grid.arrange(grobs=list(div2,div3),ncol=2),
       "diversity_measures_div_classes_sc_top50.pdf", width=12,height=10, useDingbats=FALSE, dpi=300)

library(Seurat)
library(dplyr)
library(Matrix)
library(gdata)
library(reshape2)
library(data.table)
library(ggplot2)
library(cowplot)
library(harmony)
library(gridExtra)
library(vegan)
library(tcR)
library(gtools)
library(ggpubr)
library(treemapify)
library(diverse)
library(tabula)
library(magrittr)
library(stringr)

#############################################################################################
date1="200810"
meta=fread("metadata/Sequenced_sample_metadata_020720.csv")
sc_meta=meta[meta$scRNAseqID!="",]
myCSV=fread("/metadata/Metada_Bcell_BCR.csv")
##########################################################################################
load("single_cell/data/COVIDomics_clonotypes_BCR.Rdata")

names(contigsBCR)=gsub("PC_","",names(contigsBCR))
names(contigsBCR)=gsub("Ki","Ki_",names(contigsBCR))
names(contigsBCR)=gsub("Co","Co_",names(contigsBCR))


###########################################################################################
BCRobj=list()

for (i in 1:length(contigsBCR)) {
  myname=names(contigsBCR)[i]
  y=myCSV[myCSV$orig.ident==myname,]
    #BCR
    tmp1=contigsBCR[[i]]
    tmp2=tmp1[tmp1$barcode %in% y$barcode,]
    if (nrow(tmp2)>0) {BCRobj[[myname]]=tmp2}

}
#########################################################################################
BCRclono=lapply(1:length(BCRobj),function(x){
  y=BCRobj[[x]][,c("barcode","chain","v_gene","j_gene","c_gene","cdr3","cdr3_nt")] %>%
    group_by(barcode) %>%
    summarise(chain = paste(chain, collapse="."),
              v_gene = paste(v_gene, collapse="."),
              j_gene = paste(j_gene, collapse="."),
              c_gene = paste(c_gene, collapse="."),
              cdr3 = paste(cdr3, collapse="."),
              cdr3_nt = paste(cdr3_nt, collapse="."))
  y$count=rep(1,nrow(y))
  y2= y %>%
    group_by(cdr3_nt,cdr3,c_gene,j_gene,v_gene,chain) %>%
    summarise(frequency=sum(count))
  y2$orig.ident=rep(names(BCRobj)[x],nrow(y2))
  y2$proportion=y2$frequency/sum(y2$frequency)
  y2=y2[order(y2$frequency,decreasing=T),]
  y2$clonotype_ID=paste0("clonotype",1:nrow(y2))
  y2
})
names(BCRclono)=names(BCRobj)

#BCRcont=lapply(1:length(BCRobj), function(x) {
  y=BCRobj[[x]][,c("barcode","chain","v_gene","j_gene","c_gene","cdr3","cdr3_nt")] %>%
    group_by(barcode) %>%
    summarise(chain = paste(chain, collapse="."),
              v_gene = paste(v_gene, collapse="."),
              j_gene = paste(j_gene, collapse="."),
              c_gene = paste(c_gene, collapse="."),
              cdr3 = paste(cdr3, collapse="."),
              cdr3_nt = paste(cdr3_nt, collapse="."))
  tmp=BCRclono[[x]][,c("chain","v_gene","j_gene","c_gene","cdr3","cdr3_nt","clonotype_ID")]
  z=merge(y,tmp,by=c("chain","v_gene","j_gene","c_gene","cdr3","cdr3_nt"))[,c("barcode","clonotype_ID")]
  y2=merge(BCRobj[[x]][,c("barcode","chain","v_gene","j_gene","c_gene","cdr3","cdr3_nt","reads","umis")],
           z, by=c("barcode"))
  y2
#})
#names(BCRcont)=names(BCRobj)

#################################################################################

save(BCRclono,BCRobj,file="COVIDomics_clonotypes_BCR_filtered2.Rdata")
####################################################################################################
#X cluster
BCRobj_clu=list()

for (i in 1:length(contigsBCR)) {
  myname=names(contigsBCR)[i]
  y=myCSV[myCSV$orig.ident==myname,]
  #BCR
  tmp1=contigsBCR[[i]]
  tmp2=tmp1[tmp1$barcode %in% y$barcode,]
  tmp2=merge(tmp2,y[,c("barcode","Bcell_types2")],by="barcode",all.x=TRUE)
  if (nrow(tmp2)>0) {BCRobj_clu[[myname]]=tmp2}
  #TCR
}

#########################################################################################
BCRclono_clu=lapply(1:length(BCRobj_clu),function(x){
  y=BCRobj_clu[[x]][,c("barcode","chain","v_gene","j_gene","c_gene","cdr3","cdr3_nt","Bcell_types2")] %>%
    group_by(barcode,Bcell_types2) %>%
    summarise(chain = paste(chain, collapse="."),
              v_gene = paste(v_gene, collapse="."),
              j_gene = paste(j_gene, collapse="."),
              c_gene = paste(c_gene, collapse="."),
              cdr3 = paste(cdr3, collapse="."),
              cdr3_nt = paste(cdr3_nt, collapse="."))
  y$count=rep(1,nrow(y))
  y2= y %>%
    group_by(cdr3_nt,cdr3,c_gene,j_gene,v_gene,chain,Bcell_types2) %>%
    summarise(frequency=sum(count))
  y2$orig.ident=rep(names(BCRobj)[x],nrow(y2))
#  y2$proportion=y2$frequency/sum(y2$frequency)
  y2=y2[order(y2$frequency,decreasing=T),]
  y2$clonotype_ID=paste0("clonotype",1:nrow(y2))
  y2
})
names(BCRclono_clu)=names(BCRobj_clu)
save(BCRclono_clu,BCRobj_clu,file="COVIDomics_clonotypes_BCR_filtered_clusters.Rdata")

library(Seurat)
library(dplyr)
library(Matrix)
library(gdata)
library(reshape2)
library(data.table)
library(ggplot2)
library(cowplot)
library(harmony)
library(gridExtra)
library(vegan)
library(tcR)
library(gtools)
library(ggpubr)
library(treemapify)
library(diverse)
library(tabula)
library(magrittr)
library(stringr)
downsample_DT<-function(dflist_list,n=10000,colname="cloneCount"){
  dflist=dflist_list
  dflist_copy<-lapply(dflist,copy)
  dflist_copy<-lapply(dflist_copy,function(x){x[,Read.count.down:=rmultinom(1,n,get(colname)/sum(get(colname))),];x})
  dflist_copy<-lapply(dflist_copy,function(x){x[Read.count.down>0,colname:=Read.count.down,];x})
  dflist_copy<-lapply(dflist_copy,function(x){x[Read.count.down>0,,]})
  return(dflist_copy)
}
##########################################################################################

#############################################################################################
date1="200810"
meta=fread("metadata/Sequenced_sample_metadata_020720.csv")
sc_meta=meta[meta$scRNAseqID!="",]
meta$Name=gsub("PC_","",meta$Name)
meta$Name=gsub("Ki","Ki_",meta$Name)
meta$Name=gsub("Co","Co_",meta$Name)
##########################################################################################
load("single_cell/data/COVIDomics_clonotypes_BCR_filtered2.Rdata")

BCRclono2=BCRclono_clu[which(unlist(lapply(BCRclono_clu,function(x) nrow(x)))>100)]
down=downsample_DT(dflist_list=lapply(BCRclono2, function(x) as.data.table(x)),n=min(unlist(lapply(BCRclono2,function(x) sum(x$frequency)))),colname="frequency")
down=lapply(down,function(x){
  y=x
  y$newFraction=y$Read.count.down/sum(y$Read.count.down)
  y
})
down=lapply(down, function(x) x[order(x$Read.count.down,decreasing=T),])


clonotypes_clusters=lapply(1:length(down),function(x) {
  y=down[[x]]
  y$patient=rep(names(down)[x],nrow(y))
  y$frequency=y$Read.count.down
  y
})
clonotypes_clusters=do.call(rbind,clonotypes_clusters)
clonotypes_clusters$frequency=as.numeric(clonotypes_clusters$frequency)
clonotypes_clusters=split(clonotypes_clusters,clonotypes_clusters$Bcell_types2)
clonotypes_clusters=clonotypes_clusters[-4]
#########################################################################################
div_table_clusters=c()
div_tot=c()
for (cluster in 1:length(clonotypes_clusters)) {
  clonos_dt=split(clonotypes_clusters[[cluster]],clonotypes_clusters[[cluster]]$patient)
  gini_index=cbind(unlist(lapply(clonos_dt,function(x) tcR::gini(x$frequency))))
  inv_simp=cbind(unlist(lapply(clonos_dt,function(x) vegan::diversity(x$frequency,index="invsimpson"))))
  clonotypes_normalized=cbind(unlist(lapply(clonos_dt,function(x) length(x$frequency))))
  clonality=cbind(unlist(lapply(clonos_dt,function(x) 1/(vegan::diversity(x$frequency,index="shannon")))))
  divers<-data.frame(patient=row.names(clonality),
                     No.clones_norm=clonotypes_normalized,
                     Gini=gini_index,Inv.Simpson=inv_simp, Clonality=clonality, cluster=rep(names(clonotypes_clusters)[cluster],length(clonality)))
  diversity_table=merge(divers,meta,by.x=c("patient"),by.y=c("Name"),all.x=T)
  div_table_clusters=rbind(div_table_clusters,diversity_table)
  div_tot=rbind(div_tot,divers)
}

write.table(diversity_table,"BCR_diversity measures_by_cluster.txt",
            row.names=FALSE , quote=FALSE, sep="\t",dec=".")
#########################################################
mod_melt=merge(melt(div_tot, id.vars=c("patient","cluster")),meta,by.x=c("patient"),by.y=c("Name"),all.x=T)

mod_melt$Pseudotime=factor(mod_melt$Pseudotime, levels=c(0:7))
mod_melt=mod_melt[order(mod_melt$Pseudotime),]
mod_melt$Disease_traj=factor(mod_melt$Disease_traj, levels=unique(mod_melt$Disease_traj))
mod_melt$Diagnosis=rep("COVID-19",nrow(mod_melt))
mod_melt$Diagnosis=ifelse(grepl("Healthy",mod_melt$Disease_traj),gsub("COVID-19","Healthy",mod_melt$Diagnosis),mod_melt$Diagnosis)

div2=ggplot(data=mod_melt,aes(y=value,x=Pseudotime)) +
  geom_point(size=3, aes(color=Pseudotime)) + 
  scale_color_manual(values=c("0"="#A7A9AC","1"="#E84F8C","2"="#7031B9","3"="#A04E9E","4"="#E65826","5"="#F99B1C",
                              "6"="#FDC077","7"="#51BBFE"),
                     labels=c("0"="Healthy","1"="Complicated (incremental)",
                              "2"="Critical","3"="Complicated with hyperinflammatory syndrom",
                              "4"="Complicated (recovering)","5"="Mild (recovering)",
                              "6"="recovery/asymptomatic","7"="Recovered")) +
  guides(color=guide_legend("Disease\ntrajectory")) +
  facet_grid(variable~cluster,scale="free",space="free_x") + 
  theme_bw() +
  stat_summary(fun.y= median, fun.ymin = median, fun.ymax = median,
               geom = "crossbar", width = 0.4) +
  labs(y = "Diversity measure",
       x="Disease severity",
       title="") +
  theme(text = element_text(size=12),
        axis.text.x =element_text(size=12),
        axis.title.x =element_text(size=12),
        strip.text = element_text(size = 12),
        axis.text.y =element_text(size=12),
        axis.title.y=element_text(size=12)) 

ggsave(plot=grid.arrange(grobs=list(div2),ncol=1),
       "diversity_measures_byCluster.pdf", width=12,height=10, useDingbats=FALSE, dpi=300)
#################################################################################################################
clonotypes_clusters=lapply(1:length(BCRclono2),function(x) {
  y=BCRclono2[[x]]
  y$patient=rep(names(BCRclono2)[x],nrow(y))
#  y$frequency=y$Read.count.down
  y
})
clonotypes_clusters=do.call(rbind,clonotypes_clusters)
clonotypes_clusters$frequency=as.numeric(clonotypes_clusters$frequency)
clonotypes_clusters=split(clonotypes_clusters,clonotypes_clusters$Bcell_types2)
clonotypes_clusters=clonotypes_clusters[-4]
##########
div_tot=c()
for (cluster in 1:length(clonotypes_clusters)) {
  clonos_dt=split(clonotypes_clusters[[cluster]],clonotypes_clusters[[cluster]]$patient)
classes=lapply(1:length(clonos_dt), function(x) {
  y=clonos_dt[[x]]
  y$class=rep("None",nrow(y))
  y$class=ifelse(grepl("IGHA",y$c_gene),gsub("None","IGHA",y$class),y$class)
  y$class=ifelse(grepl("IGHM",y$c_gene),gsub("None","IGHM",y$class),y$class)
  y$class=ifelse(grepl("IGHG",y$c_gene),gsub("None","IGHG",y$class),y$class)
  y$class=ifelse(grepl("IGHE",y$c_gene),gsub("None","IGHE",y$class),y$class)
  y$class=ifelse(grepl("IGHD",y$c_gene),gsub("None","IGHD",y$class),y$class)
  y=y[y$class!="None",]
  y
})

classes=classes[which(unlist(lapply(classes,function(x) nrow(x)))>=50)]
classes=do.call(rbind,lapply(1:length(classes), function(x) {
  y=classes[[x]]
  y=y[1:min(unlist(lapply(classes,function(x) nrow(x)))),]
    z=data.frame(class_clonotype=cbind(table(y$class)))
    z$class=row.names(z)
    z$Name=rep(y$patient[1],nrow(z))
    z$class_clonotype=z$class_clonotype/min(unlist(lapply(classes,function(x) nrow(x))))
    z$cluster=rep(y$Bcell_types2[1],nrow(z))
    z
    }))
div_tot=rbind(div_tot,classes)
}
mod_melt=merge(div_tot,meta,by=c("Name"),all.x=T)

mod_melt$Pseudotime=factor(mod_melt$Pseudotime, levels=c(0:7))
mod_melt=mod_melt[order(mod_melt$Pseudotime),]
mod_melt$Disease_traj=factor(mod_melt$Disease_traj, levels=unique(mod_melt$Disease_traj))

mod_melt$Diagnosis=rep("COVID-19",nrow(mod_melt))
mod_melt$Diagnosis=ifelse(grepl("Healthy",mod_melt$Disease_traj),gsub("COVID-19","Healthy",mod_melt$Diagnosis),mod_melt$Diagnosis)


div2=ggplot(data=mod_melt,aes(y=class_clonotype,x=Pseudotime)) +
  geom_point(size=3, aes(color=Pseudotime)) + 
  scale_color_manual(values=c("0"="#A7A9AC","1"="#E84F8C","2"="#7031B9","3"="#A04E9E","4"="#E65826","5"="#F99B1C",
                              "6"="#FDC077","7"="#51BBFE"),
                     labels=c("0"="Healthy","1"="Complicated (incremental)",
                              "2"="Critical","3"="Complicated with hyperinflammatory syndrom",
                              "4"="Complicated (recovering)","5"="Mild (recovering)",
                              "6"="recovery/asymptomatic","7"="Recovered")) +
  guides(color=guide_legend("Disease\ntrajectory")) +
  facet_grid(class~cluster,scale="free",space="free_x") + 
  theme_bw() +
  stat_summary(fun.y= median, fun.ymin = median, fun.ymax = median,
               geom = "crossbar", width = 0.4) +
  labs(y = "BCR proportion per class",
       x="Pseudotime",
       title="") +
  theme(text = element_text(size=12),
        axis.text.x =element_text(size=12),
        axis.title.x =element_text(size=12),
        strip.text = element_text(size = 12),
        axis.text.y =element_text(size=12),
        axis.title.y=element_text(size=12)) 

ggsave(plot=grid.arrange(grobs=list(div2),ncol=1),
       "diversity_measures_classes_sc_byCluster.pdf", width=12,height=10, useDingbats=FALSE, dpi=300)
################################################################################################################

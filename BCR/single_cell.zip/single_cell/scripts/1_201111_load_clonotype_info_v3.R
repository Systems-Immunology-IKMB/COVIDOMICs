library(Seurat)
library(dplyr)
library(Matrix)
library(gdata)
library(reshape2)
library(data.table)
library(ggplot2)
library(cowplot)
library(harmony)
library(gridExtra)
library(vegan)
library(tcR)
library(gtools)
library(ggpubr)
library(treemapify)
library(diverse)
library(tabula)
library(magrittr)
library(stringr)
#############################################################################################
date1="200810"
meta=fread("metadata/Sequenced_sample_metadata_020720.csv")
sc_meta=meta[meta$scRNAseqID!="",]
input_folder="location_of_single_cell_BCR_cellranger_outputs"
contigs_start=list()
clonos_start=list()
######################################################################################
for (i in 1:length(sc_meta$scRNAseqID)) {
  tmp=sc_meta$scRNAseqID[i]
  print(tmp)
  myname=paste0(tmp,"-L3")
  new_name=sc_meta$Name[i]
  input_folder= input_folder
  if (dir.exists(input_folder)) {
    contig=fread(paste0(input_folder,"all_contig_annotations.csv"))
    clono=fread(paste0(input_folder,"clonotypes.csv"))
    contigs_start[[new_name]]=contig
    clonos_start[[new_name]]=clono
  }
}


clonos_start=clonos_start[which(lapply(clonos_start, function(x) nrow(x))>=50)]


##########################################################################
#samples overlap with V genes
clonosBCR <- lapply(clonos_start, function(x) {
  y=x
  to_remove=c()
  for (i in 1:nrow(y)) {
    if (str_count(y$cdr3s_aa[i],"IGH") >1 & (str_count(y$cdr3s_aa[i],"IGK")>1 | str_count(y$cdr3s_aa[i],"IGL")>1) & y$frequency[i]==1) {
      to_remove=c(to_remove,i)
    } else if (str_count(y$cdr3s_aa[i],"IGH") >2 | str_count(y$cdr3s_aa[i],"IGK")>2 | str_count(y$cdr3s_aa[i],"IGL")>2) {
      to_remove=c(to_remove,i)
    } else if (str_count(y$cdr3s_aa[i],"IGH") > 1 & (str_count(y$cdr3s_aa[i],"IGK")==0 | str_count(y$cdr3s_aa[i],"IGL")==0)) {
      to_remove=c(to_remove,i)
    } else if (str_count(y$cdr3s_aa[i],"IGH") == 0 & (str_count(y$cdr3s_aa[i],"IGK")>1 | str_count(y$cdr3s_aa[i],"IGL")>1)) {
      to_remove=c(to_remove,i)
    }
  }
  z=y[-to_remove,]
  z
})
unlist(lapply(clonosBCR,function(x) nrow(x)))

clonosBCR=lapply(1:length(clonosBCR), function(x) {
  y=clonosBCR[[x]]
  y$patient=rep(names(clonosBCR)[x],nrow(y))
  y$proportion=y$frequency/sum(y$frequency)
  
  y
})

names(clonosBCR)=names(clonos_start)
contigsBCR=contigs_start[names(contigs_start) %in% names(clonosBCR)]
for (i in 1:length(contigsBCR)) {
  contigsBCR[[i]]=contigsBCR[[i]][contigsBCR[[i]]$raw_clonotype_id %in% clonosBCR[[i]]$clonotype_id,]
  contigsBCR[[i]]=contigsBCR[[i]][contigsBCR[[i]]$raw_consensus_id!="None",]
}

save(clonosBCR,contigsBCR,file= "COVIDomics_clonotypes_BCR.Rdata")
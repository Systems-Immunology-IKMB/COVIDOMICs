library(Seurat)
library(dplyr)
library(Matrix)
library(gdata)
library(reshape2)
library(data.table)
library(ggplot2)
library(cowplot)
library(harmony)
library(gridExtra)
library(vegan)
library(tcR)
library(gtools)
library(ggpubr)
library(treemapify)
library(diverse)
library(tabula)
library(magrittr)
library(packcircles)
library(ggridges)
library(ggExtra)
library(circlize)
downsample_DT<-function(dflist_list,n=10000,colname="cloneCount"){
  dflist=dflist_list
  dflist_copy<-lapply(dflist,copy)
  dflist_copy<-lapply(dflist_copy,function(x){x[,Read.count.down:=rmultinom(1,n,get(colname)/sum(get(colname))),];x})
  dflist_copy<-lapply(dflist_copy,function(x){x[Read.count.down>0,colname:=Read.count.down,];x})
  dflist_copy<-lapply(dflist_copy,function(x){x[Read.count.down>0,,]})
  return(dflist_copy)
}
merge_dt_list<-function(DTlist,colname="Read.proportion",bycol="CDR3.nucleotide.sequence"){
  cols=c(bycol,colname)
  DTlist<-lapply(DTlist,function(x) x[,..cols])
  lapply(names(DTlist),function(x)setnames(DTlist[[x]],colname,paste0(x,".",colname)))
  DTlistm<-rbindlist(DTlist,fill=T)
  print("Binded")
  
  DTlistm<-DTlistm[,lapply(.SD, sum,na.rm=T),bycol]
}

##########################################################################################
date1="200724"
meta=fread(paste0(local,"/work_ifs/sukmb345/10xGenomics/200622_COVID_PBMCS/200622_data_analysis/metadata/Sequenced_sample_metadata_020720.csv"))
sc_meta=meta[meta$scRNAseqID!="",]
load("200714_bulk_BCR.RData")
rows=unlist(lapply(BCR_covid_bulk,function(x) nrow(x)))
rows=unlist(lapply(BCR_covid_bulk,function(x) sum(x$cloneCount)))

rows[order(rows)]
test=BCR_covid_bulk[[1]]
unique(test$bestCHit)
#############################################################################################################
BCR_covid_bulk_f1=BCR_covid_bulk[names(BCR_covid_bulk) %in% meta$bulk_BCR_ID]
BCR_covid_bulk_f1=BCR_covid_bulk_f1[which(unlist(lapply(BCR_covid_bulk_f1,function(x) nrow(x)))>1000)]
mynames=names(BCR_covid_bulk_f1)
BCR_covid_bulk_f1=lapply(BCR_covid_bulk_f1,function(x){
  y=x
  y$aaVJC=paste(y$aaSeqCDR3,y$bestVHit,y$bestJHit,sep="_")
  y
})
names(BCR_covid_bulk_f1)=mynames
tab=merge_dt_list(BCR_covid_bulk_f1,bycol="aaVJC",colname="cloneCount")
tabV=merge_dt_list(BCR_covid_bulk_f1,bycol="bestVHit",colname="cloneCount")

############################################################
down=downsample_DT(dflist_list=BCR_covid_bulk_f1,n=min(unlist(lapply(BCR_covid_bulk_f1,function(x) nrow(x)))),colname="cloneCount")
down=lapply(down,function(x){
  y=x
  y$newFraction=y$Read.count.down/sum(y$Read.count.down)
  y
})
down=lapply(down, function(x) x[order(x$Read.count.down,decreasing=T),])
names(down)=names(BCR_covid_bulk_f1)
save(down,file= "COVIDomics_BCR_bulk_downsampled_2_5000.Rdata")

###############################################################
clonos_fractions=lapply(BCRclono2,function(x) {
  y=x
  y$fractions=y$frequency/sum(y$frequency)
  y
})

########################################################################################
#Diversity measured
norm_clonotypes=cbind(unlist(lapply(down,function(x) length(x$Read.count.down))))
gini_index=cbind(unlist(lapply(down,function(x) tcR::gini(x$Read.count.down))))
inv_simp=cbind(unlist(lapply(down,function(x) vegan::diversity(x$Read.count.down,index="invsimpson"))))
clonality=cbind(unlist(lapply(down,function(x) 1/(vegan::diversity(x$Read.count.down,index="shannon")))))

divers<-data.frame(bulk_BCR_ID=row.names(norm_clonotypes),No.clones=norm_clonotypes,
                   Inv.Simpson=inv_simp,Gini=gini_index, Clonality=clonality)
diversity_table=merge(divers,meta,by=c("bulk_BCR_ID"),all.x=T)
write.table(diversity_table,"COVIDomics_BCR_bulk_diversity_2_5000.txt",
            row.names=FALSE , quote=FALSE, sep="\t",dec=".")


mod_melt=merge(melt(divers),meta,by=c("bulk_BCR_ID"),all.x=T)
mod_melt$Pseudotime=factor(mod_melt$Pseudotime, levels=c(0:7))
mod_melt=mod_melt[order(mod_melt$Pseudotime),]
mod_melt$Disease_traj=factor(mod_melt$Disease_traj, levels=unique(mod_melt$Disease_traj))

mod_melt$Diagnosis=rep("COVID-19",nrow(mod_melt))
mod_melt$Diagnosis=ifelse(grepl("Healthy",mod_melt$Disease_traj),gsub("COVID-19","Healthy",mod_melt$Diagnosis),mod_melt$Diagnosis)

div=ggplot(data=mod_melt,aes(y=value,x=TimepointFromOnset, group=PatientID)) +
  geom_line(color="Grey") +
  geom_point(size=2.5, aes(color=Disease_traj)) + 
  scale_color_manual(values=unique(mod_melt$color_code)) +
  guides(color=F) +
  facet_grid(variable~.,scale="free") + 
  theme_bw() +
  #  stat_summary(fun.y= median, fun.ymin = median, fun.ymax = median,
  #               geom = "crossbar", width = 0.4) +
  labs(y = "Diversity measure",
       x="Time",
       title="") +
  theme(text = element_text(size=12),
        axis.text.x =element_text(size=12),
        axis.title.x =element_text(size=12),
        strip.text = element_text(size = 12),
        axis.text.y =element_text(size=12),
        axis.title.y=element_text(size=12)) 
#figure2A1<-ggMarginal(figure2A1,type="boxplot", groupColour=TRUE, margins="y")

div2=ggplot(data=mod_melt,aes(y=value,x=Pseudotime)) +
  geom_point(size=3, aes(color=Disease_traj)) + 
  scale_color_manual(values=unique(mod_melt$color_code)) +
  guides(color=guide_legend("Disease\ntrajectory")) +
  facet_grid(variable~.,scale="free",space="free_x") + 
  theme_bw() +
  stat_summary(fun.y= median, fun.ymin = median, fun.ymax = median,
               geom = "crossbar", width = 0.4) +
  labs(y = "Diversity measure",
       x="Disease severity",
       title="") +
  theme(text = element_text(size=12),
        axis.text.x =element_blank(),
        axis.title.x =element_text(size=12),
        strip.text = element_text(size = 12),
        axis.text.y =element_text(size=12),
        axis.title.y=element_text(size=12)) 

ggsave(plot=grid.arrange(grobs=list(div,div2),ncol=2),
       "diversity_measures_v2_5000.pdf", width=14,height=14, useDingbats=FALSE, dpi=300)
##########################################################################
BCR_covid_bulk_f1=BCR_covid_bulk[names(BCR_covid_bulk) %in% meta$bulk_BCR_ID]
BCR_covid_bulk_f1=BCR_covid_bulk_f1[which(unlist(lapply(BCR_covid_bulk_f1,function(x) nrow(x)))>1000)]

classes=do.call(rbind,lapply(1:length(BCR_covid_bulk_f1), function(x) {
  y=BCR_covid_bulk_f1[[x]][1:5000,]
  y$class=rep("IGHA",nrow(y))
  y$class=ifelse(grepl("IGHM",y$bestCHit),gsub("IGHA","IGHM",y$class),y$class)
  y$class=ifelse(grepl("IGHG",y$bestCHit),gsub("IGHA","IGHG",y$class),y$class)
  y$class=ifelse(grepl("IGHE",y$bestCHit),gsub("IGHA","IGHE",y$class),y$class)
  y$class=ifelse(grepl("IGHD",y$bestCHit),gsub("IGHA","IGHD",y$class),y$class)
  z=data.frame(class_clonotype=cbind(table(y$class)))
  z$class=row.names(z)
  z$bulk_BCR_ID=rep(names(BCR_covid_bulk_f1)[x],nrow(z))
  z$class_clonotype=z$class_clonotype/5000
  z
}))

mod_melt=merge(classes,meta,by=c("bulk_BCR_ID"),all.x=T)

write.table(mod_melt,"_COVIDomics_BCR_bulk_IGH_classes.txt",
            row.names=FALSE , quote=FALSE, sep="\t",dec=".")

mod_melt$Pseudotime=factor(mod_melt$Pseudotime, levels=c(0:7))
mod_melt=mod_melt[order(mod_melt$Pseudotime),]
mod_melt$Disease_traj=factor(mod_melt$Disease_traj, levels=unique(mod_melt$Disease_traj))

mod_melt$Diagnosis=rep("COVID-19",nrow(mod_melt))
mod_melt$Diagnosis=ifelse(grepl("Healthy",mod_melt$Disease_traj),gsub("COVID-19","Healthy",mod_melt$Diagnosis),mod_melt$Diagnosis)
mod_melt=mod_melt[order(mod_melt$Diagnosis),]
mod_melt$PatientID=factor(mod_melt$PatientID, levels=unique(mod_melt$PatientID))
mod_melt$color_code=factor(mod_melt$color_code, levels=unique(mod_melt$color_code))


div=ggplot(data=mod_melt,aes(y=class_clonotype,x=TimepointFromOnset, group=PatientID)) +
  geom_line(color="Grey") +
  geom_point(size=2.5, aes(color=Disease_traj)) + 
  scale_color_manual(values=unique(mod_melt$color_code)) +
  guides(color=F) +
  facet_grid(class~.,scale="free") + 
  theme_bw() +
  #  stat_summary(fun.y= median, fun.ymin = median, fun.ymax = median,
  #               geom = "crossbar", width = 0.4) +
  labs(y = "Diversity measure",
       x="Time",
       title="") +
  theme(text = element_text(size=12),
        axis.text.x =element_text(size=12),
        axis.title.x =element_text(size=12),
        strip.text = element_text(size = 12),
        axis.text.y =element_text(size=12),
        axis.title.y=element_text(size=12)) 

div2=ggplot(data=mod_melt,aes(y=class_clonotype,x=Pseudotime)) +
  geom_point(size=3, aes(color=Disease_traj)) + 
  scale_color_manual(values=unique(mod_melt$color_code)) +
  guides(color=guide_legend("Disease\ntrajectory")) +
  facet_grid(class~.,scale="free",space="free_x") + 
  theme_bw() +
  stat_summary(fun.y= median, fun.ymin = median, fun.ymax = median,
               geom = "crossbar", width = 0.4) +
  labs(y = "BCR proportion per class",
       x="Pseudotime",
       title="") +
  theme(text = element_text(size=12),
        axis.text.x =element_text(size=12),
        axis.title.x =element_text(size=12),
        strip.text = element_text(size = 12),
        axis.text.y =element_text(size=12),
        axis.title.y=element_text(size=12)) 

ggsave(plot=grid.arrange(grobs=list(div,div2),ncol=2),
       "diversity_measures_classes_v1.pdf", width=14,height=14, useDingbats=FALSE, dpi=300)
#

div3=ggplot(data=mod_melt[(mod_melt$Diagnosis=="COVID-19") &(mod_melt$Site=="Kiel") ,],aes(y=class_clonotype,x=TimepointFromOnset)) +
  geom_point(size=2.5, aes(color=Disease_traj, shape=class)) + 
  scale_color_manual(values=unique(mod_melt$color_code)) +
  facet_grid(.~PatientID,scale="free") + 
  theme_bw() +
  guides(color=guide_legend("Disease\ntrajectory"), shape=guide_legend("IGH class")) +
  #  stat_summary(fun.y= median, fun.ymin = median, fun.ymax = median,
  #               geom = "crossbar", width = 0.4) +
  labs(y = "IGH class proportion",
       x="Time from Onset",
       title="BCR classes") +
  theme(text = element_text(size=12),
        axis.text.x =element_blank(),
        axis.title.x =element_text(size=12),
        strip.text = element_text(size = 12),
        axis.text.y =element_text(size=12),
        axis.title.y=element_text(size=12)) 

div3.1=ggplot(data=mod_melt[(mod_melt$Diagnosis=="COVID-19")  &(mod_melt$Site=="Cologne") ,],aes(y=class_clonotype,x=TimepointFromOnset)) +
  geom_point(size=2.5, aes(color=Disease_traj, shape=class)) + 
  scale_color_manual(values=unique(mod_melt$color_code)) +
  facet_grid(.~PatientID,scale="free") + 
  theme_bw() +
  guides(color=guide_legend("Disease\ntrajectory"), shape=guide_legend("IGH class")) +
  #  stat_summary(fun.y= median, fun.ymin = median, fun.ymax = median,
  #               geom = "crossbar", width = 0.4) +
  labs(y = "IGH class proportion",
       x="Time from Onset",
       title="BCR classes") +
  theme(text = element_text(size=12),
        axis.text.x =element_blank(),
        axis.title.x =element_text(size=12),
        strip.text = element_text(size = 12),
        axis.text.y =element_text(size=12),
        axis.title.y=element_text(size=12)) 

ggsave(plot=grid.arrange(grobs=list(div3,div3.1),ncol=1),
      "diversity_measures_classes_2.pdf", width=14,height=12, useDingbats=FALSE, dpi=300)

div4=ggplot(data=mod_melt[mod_melt$Diagnosis=="Healthy",],aes(y=class_clonotype,x=PatientID)) +
  geom_point(size=2.5, aes(color=Disease_traj, shape=class)) + 
  scale_color_manual(values=unique(mod_melt$color_code)) +
  facet_grid(.~Diagnosis,scale="free") + 
  theme_bw() +
  guides(color=guide_legend("Disease\ntrajectory"), shape=guide_legend("IGH class")) +
  #  stat_summary(fun.y= median, fun.ymin = median, fun.ymax = median,
  #               geom = "crossbar", width = 0.4) +
  labs(y = "IGH class proportion",
       x="Time from Onset",
       title="BCR classes - Controls") +
  theme(text = element_text(size=12),
        axis.text.x =element_text(size=12),
        axis.title.x =element_text(size=12),
        strip.text = element_text(size = 12),
        axis.text.y =element_text(size=12),
        axis.title.y=element_text(size=12)) 

ggsave(plot=div4,
       "diversity_measures_classes_2H.pdf", width=6,height=6, useDingbats=FALSE, dpi=300)
#########################################################################################################################
BCR_covid=lapply(BCR_covid_bulk_f1, function(x) {
  y=x[1:5000,]
  y$aaVJC=paste(y$bestVHit,y$bestJHit,y$bestCHit,y$aaSeqCDR3,sep="__")
  y$aaVJC=gsub("\\*00","",y$aaVJC)
  y$rank=1:nrow(y)
  y
})

BCRtable=merge_dt_list(DTlist = BCR_covid,bycol="aaVJC",colname="rank")
BCRtable$count=rowSums(BCRtable[,2:ncol(BCRtable)]>0)
BCRtable=BCRtable[BCRtable$count>10,]

VJ=do.call(rbind,lapply(1:length(BCR_covid_bulk_f1), function(x) {
  y=BCR_covid_bulk_f1[[x]]
  y$VJC=paste(y$bestVHit,y$bestCHit,sep="__")
  y=y[grep("NA",y$VJC,invert=T)][1:5000,]
  y$VJC=gsub("\\*00","",y$VJC)
  table(y$VJC)
  z=data.frame(value=cbind(table(y$VJC)))
  z$VJC=row.names(z)
  z$bulk_BCR_ID=rep(names(BCR_covid_bulk_f1)[x],nrow(z))
  z$value=z$value/5000
  z
  }))

VJ=do.call(rbind,lapply(split(VJ,VJ$VJC),function(x) {if (nrow(x)>25) {x}}))
VJ=VJ[order(VJ$value,decreasing=T),]
VJ$VJC=factor(VJ$VJC,levels=unique(VJ$VJC))

mod_melt=merge(VJ,meta,by=c("bulk_BCR_ID"),all.x=T)
mod_melt$class=rep("IGHA",nrow(mod_melt))
mod_melt$class=ifelse(grepl("IGHM",mod_melt$VJC),gsub("IGHA","IGHM",mod_melt$class),mod_melt$class)
mod_melt$class=ifelse(grepl("IGHG",mod_melt$VJC),gsub("IGHA","IGHG",mod_melt$class),mod_melt$class)
mod_melt$class=ifelse(grepl("IGHE",mod_melt$VJC),gsub("IGHA","IGHE",mod_melt$class),mod_melt$class)
mod_melt$class=ifelse(grepl("IGHD",mod_melt$VJC),gsub("IGHA","IGHD",mod_melt$class),mod_melt$class)
mod_melt$Diagnosis=rep("COV",nrow(mod_melt))
mod_melt$Diagnosis=ifelse(grepl("Healthy",mod_melt$Disease_traj),gsub("COV","H",mod_melt$Diagnosis),mod_melt$Diagnosis)
##################################################################################################################
mod_melt2<-do.call(rbind,lapply(1:length(split(mod_melt,mod_melt$PatientID)), function(x) {
  tmp=split(mod_melt,mod_melt$PatientID)[[x]]
  tmp2<-tmp %>% group_by(VJC,PatientID,class) %>%
    summarise(value=mean(value))
  tmp2
}))
mod_melt2=mod_melt2[order(mod_melt2$value,decreasing=T),]
mod_melt2$VJC=factor(mod_melt2$VJC,levels=unique(mod_melt2$VJC))


library(viridis)
IGG1=ggplot(data=mod_melt2[mod_melt2$class=="IGHG",],aes(x=PatientID,y=VJC,fill=value)) +
  geom_raster() + scale_fill_viridis() +
 # facet_grid(.~Diagnosis + PatientID,scale="free", space="free_x") + 
  theme(text = element_text(size=12),
        axis.text.x =element_text(angle=90, hjust=1, vjust=0.5,size=12),
        axis.title.x =element_text(size=12),
        strip.text = element_text(size = 12),
        axis.text.y =element_text(size=8),
        axis.title.y=element_text(size=12)) +
  labs(x="Patient",y="BCR V gene + C gene", title="IGHG: proportion V gene usage, mean by patient")

IGA1=ggplot(data=mod_melt2[mod_melt2$class=="IGHA",],aes(x=PatientID,y=VJC,fill=value)) +
  geom_raster() + scale_fill_viridis() +
#  facet_grid(.~Diagnosis + PatientID,scale="free", space="free_x") + 
  theme(text = element_text(size=12),
        axis.text.x =element_text(angle=90, hjust=1, vjust=0.5,size=12),
        axis.title.x =element_text(size=12),
        strip.text = element_text(size = 12),
        axis.text.y =element_text(size=8),
        axis.title.y=element_text(size=12)) +
  labs(x="Patient",y="BCR V gene + C gene", title="IGHA: proportion V gene usage, mean by patient")

mod_melt3=mod_melt2[grep("IGHA|IGHG|IGHM",mod_melt2$class),]
interestingV1=ggplot(data=mod_melt3[grep("3-30|3-23|4-39|3-74|4-59|3-33|1-2|1-18",mod_melt3$VJC),],aes(x=PatientID,y=VJC,fill=value)) +
  geom_raster() + scale_fill_viridis() +
  facet_grid(class~.,scale="free", space="free_x") + 
  theme(text = element_text(size=12),
        axis.text.x =element_text(angle=90, hjust=1, vjust=0.5,size=12),
        axis.title.x =element_text(size=12),
        strip.text = element_text(size = 12),
        axis.text.y =element_text(size=8),
        axis.title.y=element_text(size=12)) +
  labs(x="Patient",y="BCR V gene + C gene", title="Abundant V gene proportion, mean by patient")

ggsave(plot=IGG1,
       "VJC_IGG_raster_byPatient.pdf", width=14,height=14, useDingbats=FALSE, dpi=300)
ggsave(plot=IGA1,
       "VJC_IGA_raster_byPatient.pdf", width=14,height=14, useDingbats=FALSE, dpi=300)
ggsave(plot=interestingV1,
       "VJC_InterestingVgenes_raster_byPatient.pdf", width=14,height=14, useDingbats=FALSE, dpi=300)
ggsave(plot=grid.arrange(IGG1,IGA1,ncol=2),
       "VJC_IGAG_raster_byPatient.pdf", width=14,height=14, useDingbats=FALSE, dpi=300)
######################################################################################
##################################################################################################################
mod_melt2<-do.call(rbind,lapply(1:length(split(mod_melt,mod_melt$Pseudotime)), function(x) {
  tmp=split(mod_melt,mod_melt$Pseudotime)[[x]]
  tmp2<-tmp %>% group_by(VJC,Pseudotime,class,Disease_traj) %>%
    summarise(value=mean(value))
  tmp2
}))
mod_melt2=mod_melt2[order(mod_melt2$value,decreasing=T),]
mod_melt2$VJC=factor(mod_melt2$VJC,levels=unique(mod_melt2$VJC))
mod_melt2$Pseudotime=factor(mod_melt2$Pseudotime,levels=c(0:7))

best=unique(mod_melt2$VJC)[1:20]

library(viridis)
xx=mod_melt2[mod_melt2$class=="IGHG",]
xx=xx[xx$VJC %in% unique(xx$VJC)[1:20],]
IGG2=ggplot(data=xx,aes(x=Pseudotime,y=VJC,fill=value)) +
  geom_raster() + scale_fill_viridis() +
  # facet_grid(.~Diagnosis + PatientID,scale="free", space="free_x") + 
  theme(text = element_text(size=12),
        axis.text.x =element_text(angle=90, hjust=1, vjust=0.5,size=12),
        axis.title.x =element_text(size=12),
        strip.text = element_text(size = 12),
        axis.text.y =element_text(size=12),
        axis.title.y=element_text(size=12)) +
  labs(x="Pseudotime",y="BCR V gene + C gene", title="IGHG: proportion V gene usage, mean by Pseudotime")

xx=mod_melt2[mod_melt2$class=="IGHA",]
xx=xx[xx$VJC %in% unique(xx$VJC)[1:20],]
IGA2=ggplot(data=xx,aes(x=Pseudotime,y=VJC,fill=value)) +
  geom_raster() + scale_fill_viridis() +
  #  facet_grid(.~Diagnosis + PatientID,scale="free", space="free_x") + 
  theme(text = element_text(size=12),
        axis.text.x =element_text(angle=90, hjust=1, vjust=0.5,size=12),
        axis.title.x =element_text(size=12),
        strip.text = element_text(size = 12),
        axis.text.y =element_text(size=12),
        axis.title.y=element_text(size=12)) +
  labs(x="Pseudotime",y="BCR V gene + C gene", title="IGHA: proportion V gene usage, mean by Pseudotime")

mod_melt3=mod_melt2[grep("IGHA|IGHG|IGHM",mod_melt2$class),]
interestingV2=ggplot(data=mod_melt3[grep("3-30|3-23|4-39|3-74|4-59|3-33|1-2|1-18",mod_melt3$VJC),],aes(x=Pseudotime,y=VJC,fill=value)) +
  geom_raster() + scale_fill_viridis() +
  facet_grid(class~.,scale="free", space="free_x") + 
  theme(text = element_text(size=12),
        axis.text.x =element_text(angle=90, hjust=1, vjust=0.5,size=12),
        axis.title.x =element_text(size=12),
        strip.text = element_text(size = 12),
        axis.text.y =element_text(size=8),
        axis.title.y=element_text(size=12)) +
  labs(x="Pseudotime",y="BCR V gene + C gene", title="Abundant V gene proportion, mean by Pseudotime")


ggsave(plot=IGG2,
       "VJC_IGG_raster_byPseudotime.pdf", width=14,height=14, useDingbats=FALSE, dpi=300)
ggsave(plot=IGA2,
       "VJC_IGA_raster_byPseudotime.pdf", width=14,height=14, useDingbats=FALSE, dpi=300)
ggsave(plot=interestingV2,
       "VJC_InterestingVgenes_raster_byPseudotime.pdf", width=14,height=14, useDingbats=FALSE, dpi=300)

ggsave(plot=grid.arrange(IGG2,IGA2,ncol=2),
      "VJC_IGAG_raster_byPseudotime.pdf", width=14,height=14, useDingbats=FALSE, dpi=300)
ggsave(plot=grid.arrange(IGG2,IGA2,ncol=2),
       "VJC_IGAG_raster_byPseudotime_small.pdf", width=12,height=8, useDingbats=FALSE, dpi=300)
ggsave(plot=grid.arrange(interestingV1,interestingV2,ncol=2),
       "VJC_InterestingVgenes_raster_byPseudotimePatient.pdf", width=14,height=14, useDingbats=FALSE, dpi=300)
######################################################################################
most_used=mod_melt[grep("3-30|3-23",mod_melt$VJC),]$VJC
mod_melt4=mod_melt[mod_melt$VJC %in% most_used,]
mod_melt4=mod_melt4[grep("IGHA|IGHG|IGHM",mod_melt4$class),]
mod_melt4$VJC=gsub("IGHV_","",mod_melt4$VJC)
mod_melt4$VJC=gsub("IGH","",mod_melt4$VJC)
mod_melt4$VJC=gsub("__*","",mod_melt4$VJC)
mod_melt4$V=rep("V30-3",nrow(mod_melt4))
mod_melt4$V=ifelse(grepl("V3-23",mod_melt4$VJC),gsub("30","23",mod_melt4$V),mod_melt4$V)
mod_melt5<-do.call(rbind,lapply(split(mod_melt4,mod_melt4$PatientID), function(x) {if (length(unique(x$Name))>1) {x}}))
mod_melt5$TimepointFromOnset=as.integer(mod_melt5$TimepointFromOnset)

div3=ggplot(data=mod_melt5[(mod_melt5$Diagnosis=="COV"),],aes(y=value,x=TimepointFromOnset,group=VJC)) +
  geom_point(size=1.5, aes(color=VJC)) + geom_line(aes(color=VJC),size=1) +
#  scale_color_manual(values=unique(mod_melt$color_code)) +
  facet_grid(class+V~PatientID,scale="free") + 
  theme_bw() +
#  guides(color=F) +
  #  stat_summary(fun.y= median, fun.ymin = median, fun.ymax = median,
  #               geom = "crossbar", width = 0.4) +
  labs(y = "IGH V gene proportion",
       x="Time from Onset (Days)",
       title="BCR most used V genes") +
  theme(text = element_text(size=10),
        axis.text.x =element_text(size=10,angle=45,vjust=0.5),
        axis.title.x =element_text(size=10),
        strip.text = element_text(size = 10),
        axis.text.y =element_text(size=10),
        axis.title.y=element_text(size=10)) 


div3.2= ggplot(data=mod_melt4[(mod_melt4$Diagnosis=="H"),],aes(y=value,x=PatientID,group=VJC)) +
  geom_point(size=2, aes(color=VJC)) + 
  #  scale_color_manual(values=unique(mod_melt$color_code)) +
  facet_grid(class+V~.,scale="free") + 
  theme_bw() +
  #  guides(color=F) +
  #  stat_summary(fun.y= median, fun.ymin = median, fun.ymax = median,
  #               geom = "crossbar", width = 0.4) +
  labs(y = "IGH V gene proportion",
       x="Controls",
       title="BCR most used V genes in Controls") +
  theme(text = element_text(size=10),
        axis.text.x =element_text(size=10),
        axis.title.x =element_text(size=10),
        strip.text = element_text(size = 10),
        axis.text.y =element_text(size=10),
        axis.title.y=element_text(size=10)) 

ggsave(plot=div3,
       "most_used_V_singlePatient.pdf", width=14,height=10, useDingbats=FALSE, dpi=300)
ggsave(plot=div3.2,
       "most_used_V_Controls.pdf", width=6,height=8, useDingbats=FALSE, dpi=300)
##################################################################################################

require(data.table)

#install.packages(c("tcR","vegan", "ggplot2", "ggfortify", "viridis"))
#FOR TEST PURPOSES THE LIST ARE REDUCED TO 1000 CLONOTYPES X SAMPLE

main1="bulk/data/clonotype_tables/"
#################################################
#FUNCTIONS
change_names=function(TRA_names,TRA, gsub_text="*.txt") {
  names(TRA)=unlist(lapply(TRA_names,function(x) gsub(gsub_text,"",x)))
  return(TRA)
}

prepare_tables=function(main, letter1="A", pattern_group=NULL) {
text_IBD=paste0(".txt")

#LIST FILES IN FOLDER TO ANALYZE
TRA_names=list.files(main)
if (is.character(pattern_group)==T) {
  pattern=as.character(pattern_group)
  TRA_names=TRA_names[grep(pattern,TRA_names)]
}
print(TRA_names)


#FREAD ALL OF THEM TO DATA.TABLE FORMAT
print("Starting reading your tables...")
TRA_tmp=lapply(TRA_names, function(x) fread(paste0(main,x), na.strings = ""))
print("tables uploaded")


#x test purposes #CHANGE NUMBERS
TRA=TRA_tmp

print("Assigning new names to tables...")
TRA_new_names=change_names(TRA_names, TRA, gsub_text=text_IBD )

samples=c(TRA_new_names)

patterns=c("\\*", "_")

print("Printing output")
out=samples

return(out)
}

######################################################################################################

BCR_covid_bulk=prepare_tables(main1, letter1="S")

name=do.call("rbind",strsplit(names(BCR_covid_bulk),split="_"))
new_names=do.call("rbind",strsplit(paste(name[,1]),split="-"))[,1]
names(BCR_covid_bulk)=new_names


save(BCR_covid_bulk, file ="200714_bulk_BCR.RData")

metadata=rbind(fread("200622_BCR_COVID_1_plate.csv"),
      fread("200624_BCR_COVID_2_plate.csv"))

names(BCR_covid_bulk)=paste(names(BCR_covid_bulk), metadata$external_name,sep=":")
save(BCR_covid_bulk, file ="200714_bulk_BCR.RData")




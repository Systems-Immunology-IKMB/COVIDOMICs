library(Seurat)
library(dplyr)
library(Matrix)
library(gdata)
library(reshape2)
library(data.table)
library(ggplot2)
library(cowplot)
library(harmony)
library(gridExtra)
library(vegan)
library(tcR)
library(gtools)
library(ggpubr)
library(treemapify)
library(diverse)
library(tabula)
library(magrittr)
library(packcircles)
library(ggridges)
library(ggExtra)
library(circlize)
downsample_DT<-function(dflist_list,n=10000,colname="cloneCount"){
  dflist=dflist_list
  dflist_copy<-lapply(dflist,copy)
  dflist_copy<-lapply(dflist_copy,function(x){x[,Read.count.down:=rmultinom(1,n,get(colname)/sum(get(colname))),];x})
  dflist_copy<-lapply(dflist_copy,function(x){x[Read.count.down>0,colname:=Read.count.down,];x})
  dflist_copy<-lapply(dflist_copy,function(x){x[Read.count.down>0,,]})
  return(dflist_copy)
}
merge_dt_list<-function(DTlist,colname="Read.proportion",bycol="CDR3.nucleotide.sequence"){
  cols=c(bycol,colname)
  DTlist<-lapply(DTlist,function(x) x[,..cols])
  lapply(names(DTlist),function(x)setnames(DTlist[[x]],colname,paste0(x,".",colname)))
  DTlistm<-rbindlist(DTlist,fill=T)
  print("Binded")
  
  DTlistm<-DTlistm[,lapply(.SD, sum,na.rm=T),bycol]
}

##########################################################################################
date1="200724"
output_folder="output_folder"

meta=fread("metadata/Sequenced_sample_metadata_020720.csv")
load("bulk/data/200714_bulk_BCR.RData")
rows=unlist(lapply(BCR_covid_bulk,function(x) nrow(x)))
rows=unlist(lapply(BCR_covid_bulk,function(x) sum(x$cloneCount)))

#############################################################################################################
BCR_covid_bulk_f1=BCR_covid_bulk[names(BCR_covid_bulk) %in% meta$bulk_BCR_ID]
BCR_covid_bulk_f1=BCR_covid_bulk_f1[which(unlist(lapply(BCR_covid_bulk_f1,function(x) nrow(x)))>1000)]
############################################################
down=downsample_DT(dflist_list=BCR_covid_bulk_f1,n=min(unlist(lapply(BCR_covid_bulk_f1,function(x) nrow(x)))),colname="cloneCount")
down=lapply(down,function(x){
  y=x
  y$newFraction=y$Read.count.down/sum(y$Read.count.down)
  y
})
down=lapply(down, function(x) x[order(x$Read.count.down,decreasing=T),])
names(down)=names(BCR_covid_bulk_f1)
save(down,file= "COVIDomics_BCR_bulk_downsampled_2_5000.Rdata")

###############################################################
clonos_fractions=lapply(BCRclono2,function(x) {
  y=x
  y$fractions=y$frequency/sum(y$frequency)
  y
})
######################################################################################## #CLONOTYPE OVERLAP BETWEEN SAMPLES
#create count/rank/proportion table
#create extra column merging V,J genes with amino acid cdr3 sequence. This is used to define clonotypes. 
#The same cdr3 region may be independentlyformed by differen VJ genes.
BCR_covid=lapply(BCR_covid_bulk_f1, function(x) {
  y=x[1:5000,]
  y$aaVJ=paste(y$bestVHit,y$bestJHit,y$aaSeqCDR3,sep="__")
  y$aaVJ=gsub("\\*00","",y$aaVJ)
  y$rank=1:nrow(y)
  y$cloneFraction_new=y$cloneCount/5000
  y
})

BCRtable=merge_dt_list(DTlist = BCR_covid,bycol="aaVJC",colname="rank") #possible to use also cloneCount or cloneFraction_new
BCRtable$count=rowSums(BCRtable[,2:ncol(BCRtable)]>0) #check in how many samples you find the same clonotype

############################################################
#V GENE USAGE -also possible for J genes
Vgenes=do.call(rbind,lapply(1:length(BCR_covid_bulk_f1), function(x) {
  y=BCR_covid_bulk_f1[[x]]
  y=y[grep("NA",y$bestVHit,invert=T)][1:5000,]
  y$bestVHit=gsub("\\*00","",y$bestVHit)
  z=data.frame(value=cbind(table(y$bestVHit))) #count clonotypes using VJ combinations
  z$Vgene=row.names(z)
  z$bulk_BCR_ID=rep(names(BCR_covid_bulk_f1)[x],nrow(z))
  z$value=z$value/5000 #transform in relative proportion
  z
}))

########################################################################
#VJ GENE USAGE
VJ=do.call(rbind,lapply(1:length(BCR_covid_bulk_f1), function(x) {
  y=BCR_covid_bulk_f1[[x]]
  y$VJ=paste(y$bestVHit,y$bestJHit,sep="__")
  y=y[grep("NA",y$VJ,invert=T)][1:5000,]
  y$VJ=gsub("\\*00","",y$VJ)
  z=data.frame(value=cbind(table(y$VJ))) #count clonotypes using VJ combinations
  z$VJ=row.names(z)
  z$bulk_BCR_ID=rep(names(BCR_covid_bulk_f1)[x],nrow(z))
  z$value=z$value/5000 #transform in relative proportion
  z
  }))

VJ=do.call(rbind,lapply(split(VJ,VJ$VJ),function(x) {if (nrow(x)>25) {x}})) #select most used genes
VJ=VJ[order(VJ$value,decreasing=T),]
VJ$VJ=factor(VJ$VJ,levels=unique(VJ$VJ))
#######################################################################
mod_melt=merge(Vgenes,meta,by=c("bulk_BCR_ID"),all.x=T)
mod_melt$Diagnosis=rep("COV",nrow(mod_melt))
mod_melt$Diagnosis=ifelse(grepl("Healthy",mod_melt$Disease_traj),gsub("COV","H",mod_melt$Diagnosis),mod_melt$Diagnosis)
mod_melt=mod_melt[order(mod_melt$value,decreasing=T),]
mod_melt$Vgene=factor(mod_melt$Vgene,levels=unique(mod_melt$Vgene))
##################################################################################################################
#take the mean values among time points
mod_melt2<-do.call(rbind,lapply(1:length(split(mod_melt,mod_melt$PatientID)), function(x) { 
  tmp=split(mod_melt,mod_melt$PatientID)[[x]]
  tmp2<-tmp %>% group_by(VJC,PatientID,class) %>%
    summarise(value=mean(value))
  tmp2
}))

#####################################################################
library(viridis)
IGG1=ggplot(data=mod_melt,aes(x=PatientID,y=Vgene,fill=value)) +
  geom_raster() + scale_fill_viridis() +
 # facet_grid(.~Diagnosis + PatientID,scale="free", space="free_x") + 
  theme(text = element_text(size=12),
        axis.text.x =element_text(angle=90, hjust=1, vjust=0.5,size=12),
        axis.title.x =element_text(size=12),
        strip.text = element_text(size = 12),
        axis.text.y =element_text(size=8),
        axis.title.y=element_text(size=12)) +
  labs(x="Patient",y="BCR V gene ", title="Proportion V gene usage")

ggsave(plot=IGG1,
       "VJC_IGG_raster_byPatient.pdf", width=14,height=14, useDingbats=FALSE, dpi=300)

######################################################################################
#for selected genes one can plot their temporal trajectories

mod_melt3=mod_melt[mod_melt$Vgene=="IGHV3-23",]
div3=ggplot(data=mod_melt3,aes(y=value,x=TimepointFromOnset,group=Patient)) +
  geom_point(size=1.5, aes(color=Patient)) + geom_line(aes(color=Patient),size=1) +
  theme_bw() +
  labs(y = "IGH V gene proportion",
       x="Time from Onset (Days)",
       title="BCR most used V genes") +
  theme(text = element_text(size=10),
        axis.text.x =element_text(size=10,angle=45,vjust=0.5),
        axis.title.x =element_text(size=10),
        strip.text = element_text(size = 10),
        axis.text.y =element_text(size=10),
        axis.title.y=element_text(size=10)) 
##################################################################################################
